from enum import Enum

class Tab(Enum):
    NONE = 0,
    DETAILS = 1,
    EDIT = 2,
    RECOMMENDATIONS = 3